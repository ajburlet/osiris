#ifndef GLXWIN_GEN_ALL_HPP
#define GLXWIN_GEN_ALL_HPP

#include "_int_glx_type.hpp"
#include "_int_glx_exts.hpp"

#endif /*GLXWIN_GEN_ALL_HPP*/
