#ifndef OPENGL_GEN_CORE_REM2_0_H
#define OPENGL_GEN_CORE_REM2_0_H

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/
#define GL_COORD_REPLACE 0x8862
#define GL_MAX_TEXTURE_COORDS 0x8871
#define GL_POINT_SPRITE 0x8861
#define GL_VERTEX_PROGRAM_TWO_SIDE 0x8643



#ifdef __cplusplus
}
#endif /*__cplusplus*/
#endif /*OPENGL_GEN_CORE_REM2_0_H*/
