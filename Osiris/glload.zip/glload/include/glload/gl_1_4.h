#ifndef OPENGL_GEN_1_4_H
#define OPENGL_GEN_1_4_H

#include "_int_gl_type.h"
#include "_int_gl_exts.h"

#include "_int_gl_1_0.h"
#include "_int_gl_1_1.h"
#include "_int_gl_1_2.h"
#include "_int_gl_1_3.h"
#include "_int_gl_1_4.h"
#endif /*OPENGL_GEN_1_4_H*/
