#ifndef OPENGL_GEN_4_0_HPP
#define OPENGL_GEN_4_0_HPP

#include "_int_gl_type.hpp"
#include "_int_gl_exts.hpp"

#include "_int_gl_1_0.hpp"
#include "_int_gl_1_1.hpp"
#include "_int_gl_1_2.hpp"
#include "_int_gl_1_3.hpp"
#include "_int_gl_1_4.hpp"
#include "_int_gl_1_5.hpp"
#include "_int_gl_2_0.hpp"
#include "_int_gl_2_1.hpp"
#include "_int_gl_3_0.hpp"
#include "_int_gl_3_1.hpp"
#include "_int_gl_3_2.hpp"
#include "_int_gl_3_3.hpp"
#include "_int_gl_4_0.hpp"
#endif /*OPENGL_GEN_4_0_HPP*/
